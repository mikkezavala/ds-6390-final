# Tax Complexity Navigator: A Visual and AI-Powered Exploration of U.S. Tax Credit Eligibility

This project aims to demystify the complexity of the U.S. tax code—specifically around eligibility for tax credits like the Earned Income Tax Credit (EITC) and Child Tax Credit (CTC)—using synthetic data, PyTorch-based machine learning, and interactive visualizations.
By simulating taxpayer profiles and encoding real IRS credit rules, we train a model to predict eligibility and visualize the dependencies, overlaps, and conflicts among tax rules.
This project bridges software engineering, AI, and public policy by creating a transparent, explainable, and intuitive view of tax complexity.


## Basic Objectives
-   Simulate thousands of taxpayer profiles using realistic tax-related variables.
-   Encode IRS tax credit rules (EITC, CTC) as conditions on taxpayer data.
-   Train ML models (binary classifiers) to predict credit eligibility.
-   Use tensors (PyTorch) to manage multi-dimensional taxpayer data.
-   Visualize eligibility conditions using D3.js (e.g., tree maps or DAGs).
-   Explain model decisions using feature attribution (SHAP or gradients).

## Motivation
-   U.S. tax credits are notoriously complex, yet they impact millions of people’s refunds and audits.
-   Even tax software engineers struggle to understand overlapping eligibility.
-   AI can learn these rules—but humans still need to see and understand what’s going on.
-   A visual + ML-powered approach helps educators, tax pros, and engineers understand edge cases and rule conflicts.